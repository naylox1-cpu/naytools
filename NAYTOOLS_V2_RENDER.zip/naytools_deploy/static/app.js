const $=s=>document.querySelector(s);
const info={
 username:["USERNAME INTELLIGENCE","Présence publique d'un pseudo","USERNAME / HANDLE","exemple_pseudo"],
 email:["EMAIL INTELLIGENCE","Configuration publique du domaine de messagerie","EMAIL ADDRESS","nom@example.com"],
 ip:["IP INTELLIGENCE","Informations réseau et géolocalisation approximative","PUBLIC IP ADDRESS","8.8.8.8"],
 domain:["DOMAIN / DNS","Enregistrements DNS, WHOIS et réponse HTTP","DOMAIN NAME","example.com"],
 phone:["PHONE METADATA","Métadonnées publiques de numérotation uniquement","INTERNATIONAL PHONE"," +33612345678"],
 url:["URL SCANNER","Réponse HTTP et redirections d'un site public","PUBLIC URL","https://example.com"]
};
let activeModule="username",lastResult=null,nodes=[],edges=[],selected=[],drag=null,positions={},caseResult=null;
function toast(s){let t=$("#toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}
function showView(id,title){document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");document.querySelectorAll(".nav[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===id));$("#topName").textContent=title}
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>{showView(b.dataset.page,b.textContent.trim());if(b.dataset.page==="cases")loadCases()});
document.querySelectorAll("[data-module]").forEach(b=>b.onclick=()=>openModule(b.dataset.module));
document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>openModule(b.dataset.open));
function openModule(k){activeModule=k;let a=info[k];$("#moduleEyebrow").textContent=a[0];$("#moduleTitle").innerHTML=a[0].split(" ")[0]+" <em>"+a[0].split(" ").slice(1).join(" ")+"</em>";$("#moduleDescription").textContent=a[1];$("#targetLabel").textContent=a[2];$("#target").placeholder=a[3];$("#target").value="";$("#results").innerHTML='<div class="result-placeholder"><div>⌕</div><b>AWAITING ANALYSIS</b><span>Les résultats détaillés apparaîtront ici.</span></div>';lastResult=null;showView("analysis",a[0])}
$("#backWorkspace").onclick=()=>showView("workspace","Investigation graph");
$("#run").onclick=async()=>{let target=$("#target").value.trim();if(!target)return toast("Saisis une cible.");$("#run").disabled=true;$("#run").textContent="ANALYSIS RUNNING...";$("#results").innerHTML='<div class="result-placeholder"><b>ANALYSIS IN PROGRESS</b><span>Interrogation des sources publiques…</span></div>';try{let r=await fetch("/api/scan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({kind:activeModule,target})});let d=await r.json();if(!r.ok)throw Error(d.error||"Analyse impossible");lastResult=d;caseResult=d;renderResults(d);log("Analyse "+activeModule+" terminée");}catch(e){$("#results").textContent="ERREUR : "+e.message}finally{$("#run").disabled=false;$("#run").textContent="RUN ANALYSIS ↗"}};
function card(label,value){if(value===undefined||value===null||value==="")value="Non communiqué";if(Array.isArray(value))value=value.length?value.join(", "):"Aucun";if(typeof value==="object")value=JSON.stringify(value);return `<div class="result-card"><small>${esc(label)}</small><b>${esc(value)}</b></div>`}
function renderResults(d){let fields=[];for(let [k,v] of Object.entries(d)){if(["kind","target","timestamp","results","dns","whois","note"].includes(k))continue;if(typeof v!=="object")fields.push(card(k.replaceAll("_"," ").toUpperCase(),v))}
let extra="";if(d.results){extra='<table class="result-table"><thead><tr><th>PLATFORM</th><th>STATUS</th><th>LINK</th></tr></thead><tbody>'+d.results.map(x=>`<tr><td>${esc(x.platform)}</td><td>${esc(x.status)}</td><td><a target="_blank" rel="noopener" href="${esc(x.url)}">Open ↗</a></td></tr>`).join("")+'</tbody></table>'}
if(d.dns){extra+='<h4>DNS RECORDS</h4><table class="result-table"><tbody>'+Object.entries(d.dns).map(([k,v])=>`<tr><th>${esc(k)}</th><td>${esc((v||[]).join(" · ")||"—")}</td></tr>`).join("")+'</tbody></table>'}
if(d.whois){extra+='<h4>WHOIS</h4><table class="result-table"><tbody>'+Object.entries(d.whois).map(([k,v])=>`<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join("")+'</tbody></table>'}
let html=`<div class="result-grid">${card("TARGET",d.target)}${card("MODULE",d.kind.toUpperCase())}${fields.join("")}</div>${extra}${d.note?`<div class="result-note">${esc(d.note)}</div>`:""}<details class="json-toggle"><summary>Afficher le JSON brut</summary><pre>${esc(JSON.stringify(d,null,2))}</pre></details>`;
$("#results").innerHTML=html;
if(d.kind==="ip"&&d.latitude&&d.longitude){let id=addNodeFromResult(d);toast("Résultat IP ajouté au graphe.");}
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("#copy").onclick=()=>{if(!lastResult)return toast("Aucun résultat à copier.");navigator.clipboard.writeText(JSON.stringify(lastResult,null,2)).then(()=>toast("JSON copié."))};
function log(s){let e=document.createElement("div");e.className="activity-line";e.innerHTML=`<i></i><span>${esc(s)}</span><time>NOW</time>`;$("#activityLog").prepend(e)}
$("#addEntity").onclick=$("#emptyAdd").onclick=()=>{$("#modal").classList.add("open");$("#entityName").focus()};
$("#closeModal").onclick=()=>$("#modal").classList.remove("open");
$("#modal").onclick=e=>{if(e.target.id==="modal")$("#modal").classList.remove("open")};
$("#confirmEntity").onclick=()=>{let name=$("#entityName").value.trim();if(!name)return toast("Entre un nom d'entité.");let type=$("#entityType").value,note=$("#entityNote").value.trim();let n={id:Date.now()+Math.random(),name,type,note};nodes.push(n);$("#entityName").value="";$("#entityNote").value="";$("#modal").classList.remove("open");drawGraph();selectNode(n.id);log("Entité ajoutée : "+name)};
$("#clearGraph").onclick=()=>{nodes=[];edges=[];selected=[];positions={};drawGraph();renderInspector();toast("Graphe réinitialisé.")};
$("#linkNodes").onclick=()=>{if(selected.length!==2)return toast("Sélectionne deux entités dans le graphe.");if(!edges.some(e=>(e.a===selected[0]&&e.b===selected[1])||(e.a===selected[1]&&e.b===selected[0])))edges.push({a:selected[0],b:selected[1]});selected=[];drawGraph();renderInspector();toast("Relation créée.")};
$("#deleteNode").onclick=()=>{if(selected.length!==1)return toast("Sélectionne une seule entité.");let id=selected[0];nodes=nodes.filter(n=>n.id!==id);edges=edges.filter(e=>e.a!==id&&e.b!==id);selected=[];drawGraph();renderInspector();toast("Entité supprimée.")};
function selectNode(id){selected=selected.includes(id)?selected.filter(x=>x!==id):[...selected,id].slice(-2);drawGraph();renderInspector()}
function renderInspector(){let n=nodes.find(x=>x.id===selected[selected.length-1]);if(!n){$("#inspectorBody").innerHTML='<div class="inspector-empty">Sélectionne une entité dans le graphe pour afficher ses informations.</div>';return}$("#inspectorBody").innerHTML=`<div class="entity-detail"><div class="entity-type">${esc(n.type.toUpperCase())}</div><h3>${esc(n.name)}</h3><div class="detail-row"><small>DESCRIPTION / CONTEXT</small>${esc(n.note||"Aucune note")}</div><div class="detail-row"><small>RELATIONS</small>${edges.filter(e=>e.a===n.id||e.b===n.id).length} lien(s)</div><div class="detail-row"><small>ENTITY ID</small>${String(n.id).slice(0,16)}</div></div>`}
function drawGraph(){let svg=$("#graphSvg"),wrap=$("#graphCanvas");if(!svg)return;let w=wrap.clientWidth,h=wrap.clientHeight;svg.setAttribute("viewBox",`0 0 ${w} ${h}`);$("#graphEmpty").style.display=nodes.length?"none":"flex";$("#nodeCount").textContent=`${nodes.length} ENTITIES / ${edges.length} LINKS`;if(!nodes.length){svg.innerHTML="";return}
nodes.forEach((n,i)=>{if(!positions[n.id]){let a=2*Math.PI*i/nodes.length-Math.PI/2;positions[n.id]={x:w/2+Math.cos(a)*Math.min(w*.34,250),y:h/2+Math.sin(a)*Math.min(h*.34,160)}}});
let out=edges.map(e=>{let a=positions[e.a],b=positions[e.b];return a&&b?`<line class="edge" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"/>`:""}).join("");
out+=nodes.map(n=>{let p=positions[n.id],s=selected.includes(n.id);return `<g class="node ${s?"selected":""}" data-id="${n.id}" transform="translate(${p.x},${p.y})"><circle r="29"/><text class="type" y="-5">${esc(n.type.toUpperCase().slice(0,12))}</text><text y="10">${esc(n.name.slice(0,18))}</text></g>`}).join("");svg.innerHTML=out;
svg.querySelectorAll(".node").forEach(g=>{g.addEventListener("click",e=>{if(drag?.moved)return;selectNode(Number(g.dataset.id))});g.addEventListener("pointerdown",e=>{let id=Number(g.dataset.id);drag={id,startX:e.clientX,startY:e.clientY,moved:false};g.setPointerCapture(e.pointerId)});g.addEventListener("pointermove",e=>{if(!drag||drag.id!==Number(g.dataset.id))return;let dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;if(drag.moved){let p=positions[drag.id];p.x+=dx;p.y+=dy;drag.startX=e.clientX;drag.startY=e.clientY;drawGraph()}});g.addEventListener("pointerup",()=>{if(drag?.id===Number(g.dataset.id)){setTimeout(()=>drag=null,0)}})});
}
window.addEventListener("resize",()=>{if($("#workspace").classList.contains("active"))drawGraph()});
function addNodeFromResult(d){let n={id:Date.now()+Math.random(),name:d.target,type:"IP address",note:`${d.city||""} ${d.country||""} · ${d.isp||""}`};nodes.push(n);drawGraph();return n}
$("#saveResult").onclick=async()=>{if(!caseResult)return toast("Lance une analyse avant de sauvegarder.");let title=caseResult.kind.toUpperCase()+" — "+caseResult.target;await saveCase(title,"Résultat d'analyse enregistré.",caseResult);toast("Résultat sauvegardé dans les dossiers.")};
$("#newCase").onclick=$("#createCase").onclick=()=>{showView("cases","Case archive");$("#caseTitle").focus()};
async function saveCase(title,notes,result){let r=await fetch("/api/cases",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title,notes,result})});if(r.ok){loadCases();return true}return false}
$("#caseTitle").addEventListener("keydown",e=>{if(e.key==="Enter")saveManualCase()});
function saveManualCase(){let title=$("#caseTitle").value.trim()||"Investigation sans titre",notes=$("#caseNotes").value.trim();saveCase(title,notes,null).then(ok=>{if(ok){$("#caseTitle").value="";$("#caseNotes").value="";toast("Dossier créé.");loadCases()}})}
$("#createCase").onclick=()=>{if($("#caseTitle").value.trim()||$("#caseNotes").value.trim())saveManualCase();else $("#caseTitle").focus()};
async function loadCases(){let r=await fetch("/api/cases"),items=await r.json();$("#caseBadge").textContent=items.length;$("#caseList").innerHTML=items.length?items.map(x=>`<div class="case-row"><div><b>${esc(x.title)}</b><small>${esc(x.created)} · ${x.result?"1 résultat attaché":"Notes / dossier"}</small></div><div class="actions"><button class="outline" onclick="window.open('/api/report/${x.id}','_blank')">HTML REPORT ↗</button><button class="outline" onclick="deleteCase('${x.id}')">DELETE</button></div></div>`).join(""):'<div class="inspector-empty">Aucun dossier pour le moment.</div>'}
window.deleteCase=async id=>{await fetch("/api/cases/"+id,{method:"DELETE"});loadCases();toast("Dossier supprimé.")};
loadCases();drawGraph();
