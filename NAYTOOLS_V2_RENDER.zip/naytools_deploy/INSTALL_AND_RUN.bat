@echo off
title NAYTOOLS V2
cd /d "%~dp0"
echo.
echo  ================================================
echo             N A Y T O O L S   V 2
echo       OSINT INTELLIGENCE WORKSPACE
echo  ================================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python est introuvable. Installe Python 3.11 ou 3.12
  echo depuis python.org puis coche "Add Python to PATH".
  pause
  exit /b 1
)
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo ERREUR : installation des dependances impossible.
  pause
  exit /b 1
)
start "" http://127.0.0.1:5000
python app.py
echo.
echo NAYTOOLS est arrete.
pause
