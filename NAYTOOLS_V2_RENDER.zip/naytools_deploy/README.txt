NAYTOOLS V2 — VERSION PUBLIABLE SUR RENDER

IMPORTANT : Netlify Drop ne peut pas exécuter le serveur Python/Flask de ce projet.
Cette version est préparée pour Render (hébergement d'application Python).

PUBLICATION (méthode simple)
1. Décompresse NAYTOOLS_V2_RENDER.zip sur ton PC.
2. Crée un dépôt GitHub (New repository), par exemple naytools. Mets-le en Private si tu préfères.
3. Dans le dépôt GitHub : Add file > Upload files. Glisse TOUS les fichiers et dossiers du projet
   (app.py, requirements.txt, Procfile, render.yaml, templates/, static/), puis Commit changes.
4. Ouvre https://render.com/ et connecte-toi avec GitHub.
5. Clique New + > Blueprint, puis sélectionne ton dépôt naytools.
6. Render détecte render.yaml. Clique Apply.
7. Attends la fin du déploiement, puis ouvre l'URL *.onrender.com affichée dans Render.

SI TU NE VOIS PAS « BLUEPRINT »
New + > Web Service > connecte le dépôt GitHub, puis vérifie :
- Runtime : Python 3
- Build Command : pip install -r requirements.txt
- Start Command : gunicorn --workers 1 --threads 4 --timeout 120 app:app
Puis clique Deploy Web Service.

À SAVOIR
- Ne publie jamais de clés API, mots de passe ou données privées dans le dépôt.
- L'offre gratuite Render peut mettre le service en veille après une période sans visite ; le premier
  chargement suivant peut prendre un peu de temps. Les conditions et limites de Render peuvent changer.
- Le stockage cases.json est local : sur l'offre gratuite, les dossiers enregistrés peuvent être perdus
  lors d'un redéploiement ou redémarrage. N'y stocke pas d'informations sensibles.
- Les recherches portent sur des données publiques. Les résultats username sont indicatifs ;
  une IP localise généralement un réseau, pas une personne ; le module téléphone ne trouve pas de propriétaire.
- Pour arrêter une analyse locale : Ctrl+C dans le terminal.

LANCEMENT LOCAL WINDOWS
Double-clique sur INSTALL_AND_RUN.bat (Python installé et ajouté au PATH requis).
