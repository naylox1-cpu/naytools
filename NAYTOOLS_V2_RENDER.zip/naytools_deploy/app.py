from flask import Flask, render_template, request, jsonify, make_response
from datetime import datetime
from urllib.parse import urlparse
import os, json, re, socket, ipaddress
import requests
import dns.resolver
import whois
import phonenumbers
from phonenumbers import carrier, geocoder, timezone

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, "cases.json")
app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False
TIMEOUT = 9
UA = {"User-Agent": "NAYTOOLS-V2/2.0 (public-data research)"}

def read_cases():
    try:
        with open(DB, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []

def write_cases(items):
    with open(DB, "w", encoding="utf-8") as f:
        json.dump(items[:100], f, ensure_ascii=False, indent=2)

def domain_from(value):
    value = value.strip()
    if "://" in value:
        value = urlparse(value).hostname or ""
    value = value.split("/")[0].split(":")[0].strip(".").lower()
    if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", value):
        raise ValueError("Domaine invalide. Exemple : example.com")
    return value

def dns_records(domain):
    result = {}
    resolver = dns.resolver.Resolver()
    resolver.lifetime = TIMEOUT
    for kind in ("A", "AAAA", "MX", "NS", "TXT", "CNAME"):
        try:
            result[kind] = [x.to_text().strip('"') for x in resolver.resolve(domain, kind)]
        except Exception:
            result[kind] = []
    return result

def scan_domain(target):
    domain = domain_from(target)
    try:
        ips = sorted({x[4][0] for x in socket.getaddrinfo(domain, None)})
    except Exception:
        ips = []
    try:
        w = whois.whois(domain)
        who = {k: str(getattr(w, k, None)) for k in ("registrar", "creation_date", "expiration_date", "name_servers", "status")}
    except Exception as e:
        who = {"note": "WHOIS non disponible", "detail": str(e)[:120]}
    http = {}
    for scheme in ("https://", "http://"):
        try:
            r = requests.get(scheme + domain, headers=UA, timeout=TIMEOUT, allow_redirects=True)
            http = {"status": r.status_code, "final_url": r.url, "server": r.headers.get("Server", "Non communiqué"),
                    "content_type": r.headers.get("Content-Type", ""), "redirect_count": len(r.history)}
            break
        except requests.RequestException:
            pass
    return {"kind": "domain", "target": domain, "ips": ips, "dns": dns_records(domain), "whois": who, "http": http}

def scan_ip(target):
    try:
        ip = ipaddress.ip_address(target.strip())
    except ValueError:
        raise ValueError("Adresse IP invalide.")
    if not ip.is_global:
        raise ValueError("Pour cette recherche, utilise une IP publique.")
    try:
        r = requests.get("https://ipwho.is/" + str(ip), timeout=TIMEOUT)
        d = r.json()
        if not d.get("success"):
            raise ValueError("Le service ne fournit pas de résultat pour cette IP.")
        c = d.get("connection") or {}
        return {"kind":"ip", "target":str(ip), "country":d.get("country"), "region":d.get("region"),
                "city":d.get("city"), "latitude":d.get("latitude"), "longitude":d.get("longitude"),
                "isp":c.get("isp"), "organization":c.get("org"), "asn":c.get("asn"),
                "note":"La géolocalisation IP est approximative et décrit généralement un réseau, pas une personne."}
    except requests.RequestException:
        raise ValueError("Service de géolocalisation temporairement inaccessible.")

def scan_email(target):
    email = target.strip()
    if not re.fullmatch(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", email):
        raise ValueError("Format d'adresse e-mail invalide.")
    domain = email.rsplit("@", 1)[1].lower()
    records = dns_records(domain)
    return {"kind":"email", "target":email, "domain":domain, "mx":records["MX"], "spf": [x for x in records["TXT"] if x.lower().startswith("v=spf1")],
            "dmarc":[], "note":"L'analyse vérifie la configuration publique du domaine. Elle ne confirme pas l'existence de la boîte ni son propriétaire."}

def scan_phone(target):
    try:
        n = phonenumbers.parse(target.strip(), None)
    except Exception:
        raise ValueError("Saisis le numéro au format international, par exemple +33612345678.")
    if not phonenumbers.is_possible_number(n):
        raise ValueError("Ce numéro ne correspond pas à un format possible.")
    return {"kind":"phone", "target":phonenumbers.format_number(n, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            "valid_numbering":phonenumbers.is_valid_number(n), "country_code":phonenumbers.region_code_for_number(n),
            "carrier":carrier.name_for_number(n, "fr"), "region":geocoder.description_for_number(n, "fr"),
            "time_zones":list(timezone.time_zones_for_number(n)),
            "note":"Métadonnées de numérotation uniquement. Aucun nom, adresse ou propriétaire n'est recherché."}

PLATFORMS = {
    "GitHub":"https://github.com/{}", "Reddit":"https://www.reddit.com/user/{}/",
    "Twitch":"https://www.twitch.tv/{}", "TikTok":"https://www.tiktok.com/@{}",
    "Instagram":"https://www.instagram.com/{}/", "Pinterest":"https://www.pinterest.com/{}/",
    "SoundCloud":"https://soundcloud.com/{}", "Medium":"https://medium.com/@{}",
    "Steam":"https://steamcommunity.com/id/{}/", "YouTube":"https://www.youtube.com/@{}"
}
def scan_username(target):
    username = target.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{2,30}", username):
        raise ValueError("Pseudo invalide (2 à 30 caractères).")
    found = []
    for name, pattern in PLATFORMS.items():
        url = pattern.format(username)
        try:
            r = requests.get(url, headers=UA, timeout=5, allow_redirects=True)
            if r.status_code == 404:
                status = "404 — non trouvé"
            elif r.status_code == 200:
                status = "200 — à vérifier manuellement"
            elif r.status_code in (401, 403, 429):
                status = "Accès limité"
            else:
                status = "HTTP " + str(r.status_code)
        except requests.RequestException:
            status = "Indisponible"
        found.append({"platform":name, "status":status, "url":url})
    return {"kind":"username", "target":username, "checked":len(found), "results":found,
            "note":"Les réponses HTTP sont indicatives : elles ne prouvent ni l'existence d'un compte ni l'identité de son titulaire."}

def scan_url(target):
    url = target.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    p = urlparse(url)
    if not p.hostname:
        raise ValueError("URL invalide.")
    try:
        resolved = socket.gethostbyname(p.hostname)
        if not ipaddress.ip_address(resolved).is_global:
            raise ValueError("Les hôtes locaux ou privés ne sont pas pris en charge.")
    except socket.gaierror:
        raise ValueError("Nom d'hôte introuvable.")
    try:
        r = requests.get(url, headers=UA, timeout=TIMEOUT, allow_redirects=True, stream=True)
        data = {"kind":"url", "target":url, "final_url":r.url, "status":r.status_code,
                "redirects":len(r.history), "server":r.headers.get("Server", "Non communiqué"),
                "content_type":r.headers.get("Content-Type", ""), "resolved_ip":resolved}
        r.close()
        return data
    except requests.RequestException:
        raise ValueError("Le site ne répond pas ou la connexion a échoué.")

SCANNERS = {"username":scan_username, "email":scan_email, "ip":scan_ip, "domain":scan_domain, "phone":scan_phone, "url":scan_url}

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/cases")
def cases_get():
    return jsonify(read_cases())

@app.post("/api/scan")
def scan():
    payload = request.get_json(silent=True) or {}
    kind, target = payload.get("kind", ""), payload.get("target", "")
    if kind not in SCANNERS:
        return jsonify({"error":"Module inconnu."}), 400
    try:
        result = SCANNERS[kind](str(target))
        result["timestamp"] = datetime.now().isoformat(timespec="seconds")
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error":str(e)}), 400
    except Exception as e:
        return jsonify({"error":"Analyse interrompue : " + str(e)[:180]}), 500

@app.post("/api/cases")
def cases_add():
    p = request.get_json(silent=True) or {}
    item = {"id":datetime.now().strftime("%Y%m%d%H%M%S%f"), "title":str(p.get("title") or "Nouveau dossier")[:90],
            "created":datetime.now().isoformat(timespec="seconds"), "notes":str(p.get("notes") or "")[:4000],
            "result":p.get("result")}
    items = read_cases()
    items.insert(0, item)
    write_cases(items)
    return jsonify(item)

@app.delete("/api/cases/<case_id>")
def cases_delete(case_id):
    write_cases([x for x in read_cases() if x.get("id") != case_id])
    return jsonify({"ok":True})

@app.get("/api/report/<case_id>")
def report(case_id):
    item = next((x for x in read_cases() if x.get("id") == case_id), None)
    if not item:
        return "Dossier introuvable", 404
    safe = json.dumps(item, ensure_ascii=False, indent=2).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    html = f"""<!doctype html><html lang='fr'><meta charset='utf-8'><title>Rapport NAYTOOLS</title>
    <style>body{{background:#090c12;color:#eaf0f8;font:15px Arial;max-width:950px;margin:40px auto;padding:20px}}
    h1{{color:#d7b45a}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#151c27;border:1px solid #344052;border-radius:12px;padding:24px}}</style>
    <h1>NAYTOOLS / RAPPORT</h1><h2>{item['title']}</h2><p>{item['created']}</p><pre>{safe}</pre></html>"""
    return make_response(html, 200, {"Content-Type":"text/html; charset=utf-8"})

if __name__ == "__main__":
    print("\\n NAYTOOLS V2 running at http://127.0.0.1:5000\\n")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
